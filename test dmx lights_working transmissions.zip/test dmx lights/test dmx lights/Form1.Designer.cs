﻿namespace DMXControl
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.TrackBar trbChannel1Iwaa;
        private System.Windows.Forms.Label lblChannel1Value;
        private System.Windows.Forms.Label lblTitle;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.trbChannel1Iwaa = new System.Windows.Forms.TrackBar();
            this.lblChannel1Value = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.trbChannel1Iwaa)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(30, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(150, 17);
            this.lblTitle.TabIndex = 2;
            this.lblTitle.Text = "DMX Channel 1";
            // 
            // trbChannel1Iwaa
            // 
            this.trbChannel1Iwaa.Location = new System.Drawing.Point(30, 40);
            this.trbChannel1Iwaa.Maximum = 255;
            this.trbChannel1Iwaa.Minimum = 0;
            this.trbChannel1Iwaa.Name = "trbChannel1Iwaa";
            this.trbChannel1Iwaa.Size = new System.Drawing.Size(300, 45);
            this.trbChannel1Iwaa.TabIndex = 0;
            this.trbChannel1Iwaa.TickFrequency = 25;
            this.trbChannel1Iwaa.Scroll += new System.EventHandler(this.trbChannel1Iwaa_Scroll);
            // 
            // lblChannel1Value
            // 
            this.lblChannel1Value.AutoSize = true;
            this.lblChannel1Value.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.lblChannel1Value.Location = new System.Drawing.Point(30, 85);
            this.lblChannel1Value.Name = "lblChannel1Value";
            this.lblChannel1Value.Size = new System.Drawing.Size(75, 15);
            this.lblChannel1Value.TabIndex = 1;
            this.lblChannel1Value.Text = "Channel 1: 0";
            // 
            // Form1
            // 
            this.ClientSize = new System.Drawing.Size(380, 130);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.lblChannel1Value);
            this.Controls.Add(this.trbChannel1Iwaa);
            this.Name = "Form1";
            this.Text = "DMX Control - COM12";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.trbChannel1Iwaa)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}